﻿
namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnReservar = new System.Windows.Forms.Button();
            this.cmbOrigen = new System.Windows.Forms.ComboBox();
            this.cmbDestino = new System.Windows.Forms.ComboBox();
            this.lblOrigen = new System.Windows.Forms.Label();
            this.lblDestino = new System.Windows.Forms.Label();
            this.lblNumeroDeAsientos = new System.Windows.Forms.Label();
            this.txtAsientosDisponibles = new System.Windows.Forms.TextBox();
            this.txtFechaSalida = new System.Windows.Forms.TextBox();
            this.lblFechasalida = new System.Windows.Forms.Label();
            this.lblAsientosReserva = new System.Windows.Forms.Label();
            this.txtoOrigenDestino = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.btnMostrarInformacionVuelo = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            this.SuspendLayout();
            // 
            // btnReservar
            // 
            this.btnReservar.Location = new System.Drawing.Point(436, 335);
            this.btnReservar.Margin = new System.Windows.Forms.Padding(4);
            this.btnReservar.Name = "btnReservar";
            this.btnReservar.Size = new System.Drawing.Size(187, 53);
            this.btnReservar.TabIndex = 0;
            this.btnReservar.Text = "RESERVAR";
            this.btnReservar.UseVisualStyleBackColor = true;
            this.btnReservar.Click += new System.EventHandler(this.btnReservar_Click_1);
            // 
            // cmbOrigen
            // 
            this.cmbOrigen.FormattingEnabled = true;
            this.cmbOrigen.Location = new System.Drawing.Point(96, 66);
            this.cmbOrigen.Margin = new System.Windows.Forms.Padding(4);
            this.cmbOrigen.Name = "cmbOrigen";
            this.cmbOrigen.Size = new System.Drawing.Size(244, 24);
            this.cmbOrigen.TabIndex = 1;
            // 
            // cmbDestino
            // 
            this.cmbDestino.FormattingEnabled = true;
            this.cmbDestino.Location = new System.Drawing.Point(377, 66);
            this.cmbDestino.Margin = new System.Windows.Forms.Padding(4);
            this.cmbDestino.Name = "cmbDestino";
            this.cmbDestino.Size = new System.Drawing.Size(244, 24);
            this.cmbDestino.TabIndex = 2;
            // 
            // lblOrigen
            // 
            this.lblOrigen.AutoSize = true;
            this.lblOrigen.Location = new System.Drawing.Point(92, 47);
            this.lblOrigen.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOrigen.Name = "lblOrigen";
            this.lblOrigen.Size = new System.Drawing.Size(47, 16);
            this.lblOrigen.TabIndex = 3;
            this.lblOrigen.Text = "Origen";
            // 
            // lblDestino
            // 
            this.lblDestino.AutoSize = true;
            this.lblDestino.Location = new System.Drawing.Point(373, 47);
            this.lblDestino.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDestino.Name = "lblDestino";
            this.lblDestino.Size = new System.Drawing.Size(53, 16);
            this.lblDestino.TabIndex = 4;
            this.lblDestino.Text = "Destino";
            // 
            // lblNumeroDeAsientos
            // 
            this.lblNumeroDeAsientos.AutoSize = true;
            this.lblNumeroDeAsientos.Location = new System.Drawing.Point(93, 191);
            this.lblNumeroDeAsientos.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNumeroDeAsientos.Name = "lblNumeroDeAsientos";
            this.lblNumeroDeAsientos.Size = new System.Drawing.Size(201, 16);
            this.lblNumeroDeAsientos.TabIndex = 5;
            this.lblNumeroDeAsientos.Text = "Numero de asientos disponibles";
            // 
            // txtAsientosDisponibles
            // 
            this.txtAsientosDisponibles.Location = new System.Drawing.Point(95, 211);
            this.txtAsientosDisponibles.Margin = new System.Windows.Forms.Padding(4);
            this.txtAsientosDisponibles.Name = "txtAsientosDisponibles";
            this.txtAsientosDisponibles.Size = new System.Drawing.Size(203, 22);
            this.txtAsientosDisponibles.TabIndex = 6;
            // 
            // txtFechaSalida
            // 
            this.txtFechaSalida.Location = new System.Drawing.Point(377, 211);
            this.txtFechaSalida.Margin = new System.Windows.Forms.Padding(4);
            this.txtFechaSalida.Name = "txtFechaSalida";
            this.txtFechaSalida.Size = new System.Drawing.Size(203, 22);
            this.txtFechaSalida.TabIndex = 7;
            // 
            // lblFechasalida
            // 
            this.lblFechasalida.AutoSize = true;
            this.lblFechasalida.Location = new System.Drawing.Point(374, 191);
            this.lblFechasalida.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFechasalida.Name = "lblFechasalida";
            this.lblFechasalida.Size = new System.Drawing.Size(85, 16);
            this.lblFechasalida.TabIndex = 8;
            this.lblFechasalida.Text = "Fecha salida";
            // 
            // lblAsientosReserva
            // 
            this.lblAsientosReserva.AutoSize = true;
            this.lblAsientosReserva.Location = new System.Drawing.Point(92, 260);
            this.lblAsientosReserva.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAsientosReserva.Name = "lblAsientosReserva";
            this.lblAsientosReserva.Size = new System.Drawing.Size(180, 16);
            this.lblAsientosReserva.TabIndex = 10;
            this.lblAsientosReserva.Text = "Asientos que desea reservar";
            // 
            // txtoOrigenDestino
            // 
            this.txtoOrigenDestino.Location = new System.Drawing.Point(96, 151);
            this.txtoOrigenDestino.Margin = new System.Windows.Forms.Padding(4);
            this.txtoOrigenDestino.Name = "txtoOrigenDestino";
            this.txtoOrigenDestino.Size = new System.Drawing.Size(525, 22);
            this.txtoOrigenDestino.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(98, 131);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 16);
            this.label1.TabIndex = 12;
            this.label1.Text = "Origen Destino";
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Location = new System.Drawing.Point(95, 279);
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(120, 22);
            this.numericUpDown2.TabIndex = 14;
            // 
            // btnMostrarInformacionVuelo
            // 
            this.btnMostrarInformacionVuelo.Location = new System.Drawing.Point(238, 112);
            this.btnMostrarInformacionVuelo.Name = "btnMostrarInformacionVuelo";
            this.btnMostrarInformacionVuelo.Size = new System.Drawing.Size(221, 32);
            this.btnMostrarInformacionVuelo.TabIndex = 15;
            this.btnMostrarInformacionVuelo.Text = "INFORMACION DE VUELO";
            this.btnMostrarInformacionVuelo.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.btnMostrarInformacionVuelo);
            this.Controls.Add(this.numericUpDown2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtoOrigenDestino);
            this.Controls.Add(this.lblAsientosReserva);
            this.Controls.Add(this.lblFechasalida);
            this.Controls.Add(this.txtFechaSalida);
            this.Controls.Add(this.txtAsientosDisponibles);
            this.Controls.Add(this.lblNumeroDeAsientos);
            this.Controls.Add(this.lblDestino);
            this.Controls.Add(this.lblOrigen);
            this.Controls.Add(this.cmbDestino);
            this.Controls.Add(this.cmbOrigen);
            this.Controls.Add(this.btnReservar);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnReservar;
        private System.Windows.Forms.ComboBox cmbOrigen;
        private System.Windows.Forms.ComboBox cmbDestino;
        private System.Windows.Forms.Label lblOrigen;
        private System.Windows.Forms.Label lblDestino;
        private System.Windows.Forms.Label lblNumeroDeAsientos;
        private System.Windows.Forms.TextBox txtAsientosDisponibles;
        private System.Windows.Forms.TextBox txtFechaSalida;
        private System.Windows.Forms.Label lblFechasalida;
        private System.Windows.Forms.Label lblAsientosReserva;
        private System.Windows.Forms.TextBox txtoOrigenDestino;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.Button btnMostrarInformacionVuelo;
    }
}

