﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp2;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        private Vuelo vuelo;
        private object numericCantidadReserva;
        private Dictionary<string, (DateTime fechaSalida, int asientosDisponibles)> datosVuelos;

        public Form1()
        {

            {
                InitializeComponent();

                // Inicializar el diccionario de datos de vuelos con las combinaciones predefinidas
                datosVuelos = new Dictionary<string, (DateTime, int)>
            {
                { "BOGOTADUBAI", (DateTime.Now.AddDays(1), 100) },
                { "CALIMONACO", (DateTime.Now.AddDays(2), 150) },
                { "MEDELLINPARIS", (DateTime.Now.AddDays(3), 200) }
            };

                // Predefinir las ciudades de origen y destino en ComboBox
                cmbOrigen.Items.AddRange(new string[] { "BOGOTA", "CALI", "MEDELLIN" });
                cmbDestino.Items.AddRange(new string[] { "DUBAI", "MONACO", "PARIS" });

                btnMostrarInformacionVuelo.Click += btnMostrarInformacionVuelo_Click;
            }

        }

         private void ActualizarInformacionVuelo()
        {
            // Obtener las ciudades de origen y destino seleccionadas
            string origen = cmbOrigen.SelectedItem.ToString();
            string destino = cmbDestino.SelectedItem.ToString();

            // Establecer los valores del vuelo según la combinación de origen y destino
            switch (origen + destino)
            {
                case "BOGOTADUBAI":
                    vuelo = new Vuelo("BOGOTA", "DUBAI", DateTime.Now.AddDays(1), 100);
                    break;
                case "CALIMONACO":
                    vuelo = new Vuelo("CALI", "MONACO", DateTime.Now.AddDays(2), 150);
                    break;
                case "MEDELLINPARIS":
                    vuelo = new Vuelo("MEDELLIN", "PARIS", DateTime.Now.AddDays(3), 200);
                    break;
                default:
                    vuelo = null;
                    break;
            }

          
            MostrarInformacionVuelo();
        }

        private void btnReservar_Click_1(object sender, EventArgs e)
        {
            if (vuelo == null)
            {
                MessageBox.Show("Por favor, seleccione una combinación válida de origen y destino.");
                return;
            }

            // Realizar la reserva de asientos
            int cantidad = (int)numericUpDown2.Value;
            bool reservaExitosa = vuelo.ReservarAsientos(cantidad);

            if (reservaExitosa)
            {
                MessageBox.Show($"¡Reserva exitosa para {cantidad} asientos!");
                MostrarInformacionVuelo();
            }
            else
            {
                MessageBox.Show("No hay suficientes asientos disponibles para realizar la reserva.");
            }
        }

        private void MostrarInformacionVuelo()
        {
            if (vuelo != null)
            {
                txtoOrigenDestino.Text = $"Origen: {vuelo.Origen} - Destino: {vuelo.Destino}";
                txtFechaSalida.Text = $"Fecha de Salida: {vuelo.FechaSalida.ToString()}";
                txtAsientosDisponibles.Text = $"Asientos Disponibles: {vuelo.AsientosDisponibles}";
            }
        }

        private void cmbOrigen_SelectedIndexChanged(object sender, EventArgs e)
        {
            ActualizarInformacionVuelo();
        }

        private void cmbDestino_SelectedIndexChanged(object sender, EventArgs e)
        {
            ActualizarInformacionVuelo();
        }

        private void btnMostrarInformacionVuelo_Click(object sender, EventArgs e)
        {
            ActualizarInformacionVuelo();
        }

    }
}


