﻿namespace WindowsFormsApp7
{
	partial class Form1
	{
		/// <summary>
		/// Variable del diseñador necesaria.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Limpiar los recursos que se estén usando.
		/// </summary>
		/// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Código generado por el Diseñador de Windows Forms

		/// <summary>
		/// Método necesario para admitir el Diseñador. No se puede modificar
		/// el contenido de este método con el editor de código.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnPrestar = new System.Windows.Forms.Button();
			this.btnSalir = new System.Windows.Forms.Button();
			this.btnDevolver = new System.Windows.Forms.Button();
			this.cmbLibros = new System.Windows.Forms.ComboBox();
			this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
			this.SuspendLayout();
			// 
			// btnPrestar
			// 
			this.btnPrestar.Location = new System.Drawing.Point(194, 313);
			this.btnPrestar.Name = "btnPrestar";
			this.btnPrestar.Size = new System.Drawing.Size(123, 64);
			this.btnPrestar.TabIndex = 1;
			this.btnPrestar.Text = "PRESTAR";
			this.btnPrestar.UseVisualStyleBackColor = true;
			this.btnPrestar.Click += new System.EventHandler(this.btnPrestar_Click);
			// 
			// btnSalir
			// 
			this.btnSalir.Location = new System.Drawing.Point(537, 313);
			this.btnSalir.Name = "btnSalir";
			this.btnSalir.Size = new System.Drawing.Size(123, 64);
			this.btnSalir.TabIndex = 2;
			this.btnSalir.Text = "SALIR";
			this.btnSalir.UseVisualStyleBackColor = true;
			this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
			// 
			// btnDevolver
			// 
			this.btnDevolver.Location = new System.Drawing.Point(368, 313);
			this.btnDevolver.Name = "btnDevolver";
			this.btnDevolver.Size = new System.Drawing.Size(123, 64);
			this.btnDevolver.TabIndex = 3;
			this.btnDevolver.Text = "DEVOLVER";
			this.btnDevolver.UseVisualStyleBackColor = true;
			this.btnDevolver.Click += new System.EventHandler(this.btnDevolver_Click);
			// 
			// cmbLibros
			// 
			this.cmbLibros.FormattingEnabled = true;
			this.cmbLibros.Location = new System.Drawing.Point(281, 117);
			this.cmbLibros.Name = "cmbLibros";
			this.cmbLibros.Size = new System.Drawing.Size(267, 28);
			this.cmbLibros.TabIndex = 4;
			this.cmbLibros.SelectedIndexChanged += new System.EventHandler(this.cmbLibros_SelectedIndexChanged);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.cmbLibros);
			this.Controls.Add(this.btnDevolver);
			this.Controls.Add(this.btnSalir);
			this.Controls.Add(this.btnPrestar);
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Button btnPrestar;
		private System.Windows.Forms.Button btnSalir;
		private System.Windows.Forms.Button btnDevolver;
		private System.Windows.Forms.ComboBox cmbLibros;
		private System.ComponentModel.BackgroundWorker backgroundWorker1;
	}
}

