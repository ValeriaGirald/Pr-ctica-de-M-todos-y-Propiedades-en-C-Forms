﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp7
{
	internal class clsLibro
	{
		public string Titulo { get; set; }
		public string Autor { get; set; }
		public int AñoPublicacion { get; set; }
		public bool Disponible { get; set; } = true;

		public string ObtenerInformacionLibro()
		{
			string estado = Disponible ? "Disponible" : "Prestado";
			return $"Título: {Titulo} | Autor: {Autor} | Año de Publicación: {AñoPublicacion} | Estado: {estado}";
		}
	}
}
