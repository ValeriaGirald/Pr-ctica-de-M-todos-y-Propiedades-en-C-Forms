﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
	public partial class Form1 : Form
	{
		clsLibro libro = new clsLibro();
		private List<clsLibro> biblioteca = new List<clsLibro>();


		public Form1()
		{
			InitializeComponent();
			cargarlibros(null, EventArgs.Empty);

		}
		private void cargarlibros(object sender, EventArgs e)
		{
			clsLibro libro1 = new clsLibro { Titulo = "El Señor de los Anillos", Autor = "J.R.R. Tolkien", AñoPublicacion = 1954 };
			clsLibro libro2 = new clsLibro { Titulo = "Cien años de soledad", Autor = "Gabriel García Márquez", AñoPublicacion = 1967 };
			clsLibro libro3 = new clsLibro { Titulo = "Padre rico Padre pobre", Autor = "George Orwell", AñoPublicacion = 1949 };
			biblioteca.Add(libro1);
			biblioteca.Add(libro2);
			biblioteca.Add(libro3);
			cmbLibros.Items.Add(libro1.Titulo);
			cmbLibros.Items.Add(libro2.Titulo);
			cmbLibros.Items.Add(libro3.Titulo);
			
		}

		private void cmbLibros_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (cmbLibros.SelectedIndex != -1)
			{
				clsLibro libroSeleccionado = biblioteca[cmbLibros.SelectedIndex];
				string mensaje = libroSeleccionado.ObtenerInformacionLibro();
				MessageBox.Show(mensaje);

				btnPrestar.Enabled = libroSeleccionado.Disponible;

				btnDevolver.Enabled = !libroSeleccionado.Disponible;
			}
		}
		private void ActualizarEstado()
		{
			if (cmbLibros.SelectedIndex != -1)
			{
				clsLibro libroSeleccionado = biblioteca[cmbLibros.SelectedIndex];
				string mensaje = libroSeleccionado.ObtenerInformacionLibro();
				MessageBox.Show(mensaje);
				btnDevolver.Enabled = !libroSeleccionado.Disponible;
				btnPrestar.Enabled = libroSeleccionado.Disponible;


			}
		}

		private void btnPrestar_Click(object sender, EventArgs e)
		{
			if (cmbLibros.SelectedIndex != -1)
			{
				clsLibro libroSeleccionado = biblioteca[cmbLibros.SelectedIndex];
				if (libroSeleccionado.Disponible)
				{
					libroSeleccionado.Disponible = false;
					MessageBox.Show($"Se ha prestado el libro: {libroSeleccionado.Titulo}");
					ActualizarEstado();
				}
				else
				{
					MessageBox.Show($"El libro {libroSeleccionado.Titulo} no está disponible actualmente.");
				}
			}
			else
			{
				MessageBox.Show("Por favor, seleccione un libro de la lista.");
			}
		}

		private void btnDevolver_Click(object sender, EventArgs e)
		{
			if (cmbLibros.SelectedIndex != -1)
			{
				clsLibro libroSeleccionado = biblioteca[cmbLibros.SelectedIndex];
				if (!libroSeleccionado.Disponible)
				{
					libroSeleccionado.Disponible = true;
					MessageBox.Show($"Se ha devuelto el libro: {libroSeleccionado.Titulo}");
					ActualizarEstado();
				}
				else
				{
					MessageBox.Show($"El libro {libroSeleccionado.Titulo} ya está disponible.");
				}
			}
			else
			{
				MessageBox.Show("Por favor, seleccione un libro de la lista.");
			}
		}

		private void btnSalir_Click(object sender, EventArgs e)
		{
			DialogResult resultado = MessageBox.Show("¿Estás seguro de que quieres salir?", "Confirmación de salida", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

			if (resultado == DialogResult.Yes)
			{
				Application.Exit(); 
			}
		}
	}
	
}
